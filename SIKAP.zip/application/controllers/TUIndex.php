<?php

class TUIndex extends CI_Controller {


}

?>