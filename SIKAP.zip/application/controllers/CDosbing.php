<?php

class CDosbing extends CI_Controller {

    public function index() {

    }

    public function list() {
        
    }

}

?>