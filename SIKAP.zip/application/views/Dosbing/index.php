<div class="container vh-75">
            <div class="row tuindex">
                <div class="col-12 d-flex justify-content-center align-items-center">
                    <div class="row">
                        <div class="col-12 d-flex justify-content-center align-items-center my-4">
                            <a href="<?php echo base_url('koordosbing') ?>">
                                <div class="dosen-box rounded p-3 d-flex align-items-center justify-content-center">
                                    <div class="row vw-100">
                                        <div class="col-4">

                                        </div>
                                        <div class="test col-8">
                                            <h2>PEMBAGIAN DOSEN PEMBIMBING</h2>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center my-4">
                            <a href="<?php echo base_url('datadosbing') ?>">
                                <div class="mhs-box rounded p-3 d-flex align-items-center justify-content-center">
                                    <div class="row vw-100">
                                        <div class="col-4">

                                        </div>
                                        <div class="test col-8">
                                            <h2>DAFTAR MAHASISWA PEMBIMBING</h2>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>